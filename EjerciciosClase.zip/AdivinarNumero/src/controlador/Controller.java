package controlador;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import modelo.Intento;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/logica")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession se = request.getSession();
		String rutaJSP = "/jsp/juego.jsp";
		ArrayList<Intento> juego = new ArrayList<>();
		int intentos=0;

		if (request.getParameter("iniciar") != null) {
			int maximo = Integer.parseInt(request.getParameter("max"));
			
			  se.setAttribute("maxi", maximo); 
			  int maxCtx = Integer.parseInt(se.getAttribute("maxi").toString());
			 

			int minimo = Integer.parseInt(request.getParameter("min"));
			
			 se.setAttribute("mini", minimo); 
			 int minCtx = Integer.parseInt(se.getAttribute("mini").toString());
			 

			int aleatorio = (int) (Math.random() * maximo + minimo);
			se.setAttribute("rnd", aleatorio);
			System.out.println(aleatorio);

		}

		int entCtx = 0;

		if (request.getParameter("prueba") != null) {
			int rnd = Integer.parseInt(se.getAttribute("rnd").toString());
			
			// se.setAttribute("entrada", entrada);
			
			do {
				
				int entrada = Integer.parseInt(request.getParameter("intento"));
				entCtx = entrada;
				// entCtx = Integer.parseInt(se.getAttribute("entrada").toString());

				if (rnd < entCtx) {
					
					System.out.println("M�s bajo");
					System.out.println(intentos);
				}

				else if (rnd > entCtx) {

					System.out.println("M�s alto"); 
					System.out.println(intentos);
				}

				else if (rnd == entCtx) {

					System.out.println("Correcto. Lo has conseguido en " + intentos + " intentos.");
					System.out.println(intentos);

				}
			} while (rnd != entCtx && request.getParameter("prueba") == "�A JUGAR!");

		}

		// System.out.println("Introduce un n�mero, por favor...");

		RequestDispatcher rd = request.getServletContext().getRequestDispatcher(rutaJSP);
		
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

	}
}
