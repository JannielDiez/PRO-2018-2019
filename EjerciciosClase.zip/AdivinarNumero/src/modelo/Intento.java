package modelo;

import java.time.LocalDate;

public class Intento {



	private LocalDate fecha;
	private int intentos;
	private int numeroJugado;
	private String mensaje;
	
	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getIntentos() {
		return intentos;
	}

	public void setIntentos(int intentos) {
		this.intentos = intentos;
	}

	public int getNumeroJugado() {
		return numeroJugado;
	}

	public void setNumeroJugado(int numeroJugado) {
		this.numeroJugado = numeroJugado;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	
	public Intento(LocalDate fecha, int intentos, int numeroJugado, String mensaje) {
		super();
		this.fecha = fecha;
		this.intentos = intentos;
		this.numeroJugado = numeroJugado;
		this.mensaje = mensaje;
	}
	public Intento() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Intento [fecha=" + fecha + ", intentos=" + intentos + ", numeroJugado=" + numeroJugado + ", mensaje="
				+ mensaje + "]";
	}

	
}
