package crunchify.web.service;

public class HelloWorld {
	
	
	public float addValue(float value) {
		return (value+10);
	}
	
	public float subtractValue(float value) {
		return (value-10);
	}
}
