package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/logica")
public class ServletPrincipal extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;

	public ServletPrincipal() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String id = request.getParameter("id");
		String ruta="";
		switch (id) {
		case "sin":
			System.out.println("sin");
			ruta="/jsp_files/sinJSLT.jsp";
			break;
		case "con":
			System.out.println("con");
			ruta="/jsp_files/conJSLT.jsp";
			break;
		}
		ServletContext sc = getServletContext();
	    RequestDispatcher rd = sc.getRequestDispatcher(ruta);
	    rd.forward(request, response);

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		ArrayList<Object> miArrayList = new ArrayList<Object>();
		miArrayList.add("Janniel");
		miArrayList.add(22);
		miArrayList.add(true);
		miArrayList.add(1.3f);
		this.getServletContext().setAttribute("miArrayList", miArrayList);

		Object[] miArray = { "Janniel", 22, true, 1.3f };
		this.getServletContext().setAttribute("miArray", miArray);

		HashMap<String, Object> miMapa = new HashMap<String, Object>();
		miMapa.put("Nombre", "Janniel");
		miMapa.put("Edad", 22);
		miMapa.put("Boolean", true);
		miMapa.put("Float", 1.3f);
		this.getServletContext().setAttribute("miMapa", miMapa);
	}
}
