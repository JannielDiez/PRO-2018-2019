package utilidades;

import java.sql.Connection;
import modelo.Libro;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Request;

public class Conexion {
	private String host;
	private String bd;
	private String usr;
	private String clave;
	private static Connection conexion;

	public static Connection conectar(String host, String bd, String usr, String clave) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://" + host + "/" + bd + "?useSSL=false";
			conexion = DriverManager.getConnection(url, usr, clave);
		} catch (SQLException e) {
			System.out.println("Error sql -> " + e.getMessage());
			return null;
		} catch (ClassNotFoundException e) {
			System.out.println("Error carga del driver -> " + e.getMessage());
		}

		return conexion;
	}
	
	public static ArrayList<Object> getAllDatabases() {
		ArrayList<Object> resultado= new ArrayList<Object>();
		//String sql ="SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN('mysql','information_schema','performance_schema','phpmyadmin')";
		String sql="SELECT * FROM SCHEMATA WHERE schema_name NOT IN('mysql','information_schema','performance_schema','phpmyadmin')";
		try {
			conexion = conectar("localhost:3306", "information_schema", "root", "");
			Statement stmt = conexion.createStatement();
			ResultSet rS = stmt.executeQuery(sql);
			while (rS.next()) {
				Object dataBase = new Object();
				dataBase=rS.getString("schema_name");
				resultado.add(dataBase);

			}
			System.out.println(resultado);
			return resultado;

		} catch (SQLException e) {
			System.out.println("No hay Bases de datos -> " + e.getMessage());
		}
		return resultado;
	}
	public static ArrayList<String> mostrarTablas(String bd) {
		
		ArrayList<String> resultado=new ArrayList<String>();
		String sql = "SHOW TABLES FROM "+bd+";";
		try {
			conexion = conectar("localhost:3306", bd, "root", "");
			Statement stmt = conexion.createStatement();
			ResultSet rS = stmt.executeQuery(sql);
			while (rS.next()) {
				String tabla;
				tabla=(rS.getString("Tables_in_"+bd));
				resultado.add(tabla);
			}
			
			return resultado;

		} catch (SQLException e) {
			System.out.println("No hay Tablas -> " + e.getMessage());
		}
		return resultado;
	}

	public static ArrayList<HashMap<String, Object>> mostrarParametros(String table,String bd) {
		
		ArrayList<HashMap<String, Object>> registros = new ArrayList<HashMap<String, Object>>();
		String sql = "SELECT * FROM " + table+";";
		try {
			conexion = conectar("localhost:3306", bd, "root", "");
			Statement stm = conexion.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			ResultSetMetaData metaData = rs.getMetaData();
			rs.first();
			if (rs.getRow() == 0) {
				System.out.println("NO HAY REGISTROS");
				stm.close();
				rs.close();
				return null;
			} else
				rs.beforeFirst();
			while (rs.next()) {

				HashMap<String, Object> registro = new HashMap<String, Object>();
				registros.add(registro);
				for (int i = 1; i <= metaData.getColumnCount(); i++) {
					registro.put(metaData.getColumnName(i), rs.getString(i));
					
				}

				System.out.println();
			}

			stm.close();
			rs.close();
			return registros;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return registros;
	}
	
	
	public static ArrayList<Libro> getAllLibros() {
		ArrayList<Libro> resultado = new ArrayList<Libro>();
		// Statement, PreparedStatement, ResultSet, MetaData
		String sql = "SELECT * FROM books ";
		try {
			conexion = conectar("localhost:3306", "shop", "root", "");
			Statement stmt = conexion.createStatement();
			ResultSet rS = stmt.executeQuery(sql);

			if (!rS.first())// no hay registros
				return null;

			while (rS.next()) {
				Libro libro = new Libro();
				libro.setId(rS.getInt(1));
				libro.setAutor(rS.getString("author"));
				libro.setTitulo(rS.getString(2));
				libro.setPrecio(rS.getDouble("price"));
				libro.setCat_id(rS.getInt(5));
				resultado.add(libro);

			}
			return resultado;

		} catch (SQLException e) {
			System.out.println("Error leyendo libros -> " + e.getMessage());
		}
		return resultado;
	}

}
