package utilidades;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelo.Libro;

public class Conexion {
	private String host;
	private String bd;
	private String usr;
	private String clave;
	private static Connection conexion;

	public static Connection conectar(String host, String bd, String usr, String clave) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://" + host +"/"+ bd + "?useSSL=false";
			conexion = DriverManager.getConnection(url, usr, clave);
		} catch (SQLException e) {
			System.out.println("Error sql -> " + e.getMessage());
			return null;
		} catch (ClassNotFoundException e) {
			System.out.println("Error carga del driver -> " + e.getMessage());
		}

		return conexion;
	}

	public static ArrayList<Libro> getAllLibros() {
		ArrayList<Libro> resultado = new  ArrayList<Libro>();
		
		
		try {
			String sql = "SELECT * FROM books";
			conexion = conectar("localhost:3306", "shop", "root", "");
			Statement stmt = conexion.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			
			while (result.next()) {
				Libro unLibro = new Libro();
				unLibro.setId(result.getInt(1));
				unLibro.setTitulo(result.getString(2));
				unLibro.setAutor(result.getString(3));
				unLibro.setPrecio(result.getInt(4));
				unLibro.setCatId(result.getInt(5));
				resultado.add(unLibro);			
			}		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error SQL");
		}
		return resultado;
		
	}
	
	public void actualizaUnLibro(Libro libro) {
		
		
		try {
			String sql = "update books set titulo = ?, autor = ?, precio = ?, catId = ? where id = ?";
			conexion = conectar("localhost:3306", "shop", "root", "");
			Statement stmt = conexion.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			
			PreparedStatement preState = conexion.prepareStatement(sql);
			//establecemos cuales ser�n los valores de la consulta sql por cada "?" tenemos debajo que valores asignamos por el orden de las columnas
			
			preState.setString(1, libro.getTitulo());
			preState.setString(2, libro.getAutor());
			preState.setDouble(3, libro.getPrecio());
			preState.setInt(4, libro.getCatId());
			preState.setInt(5, libro.getId());
			preState.execute();		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error SQL");
		}
		
	}
	
}
