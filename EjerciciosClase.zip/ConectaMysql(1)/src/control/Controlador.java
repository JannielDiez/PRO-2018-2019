package control;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import modelo.Libro;
import utilidades.Conexion;

/**
 * Servlet implementation class Controlador
 */
@WebServlet("/conecta")
public class Controlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection cnx;
	String mensaje = "Conectado con �xito";
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controlador() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		int id = 0;
		String opcion = request.getParameter("opcion");
		if (opcion.contains(",")) {
			String[] valores = opcion.split(",");
			opcion = valores[0];
			id = Integer.parseInt(valores[1]);
		}
		String ruta = null;
		System.out.println("opcion: " + opcion + " id: " + id);
		switch (opcion) {
		case "conectar":
			ruta = "mensaje";
			opcion1(request);
			break;
		case "listar":
			ruta = "libros";
			option2(request, session);
			break;
		case "modificar":
			ruta = "modificarLibro";
			option3(request, session, id);
			break;
		case "actualizar":
			ruta = "libros";
			option4(request, session);
			break;
		default:
			break;
		}

		request.setAttribute("mensaje", mensaje);
		request.getRequestDispatcher("jsp/" + ruta + ".jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	public void opcion1(HttpServletRequest request) {
		cnx = Conexion.conectar("localhost:3306", "shop", "root", "");
		if (cnx == null) mensaje = "Error de conexi�n...";
		request.setAttribute("mensaje", mensaje);
	}

	public void option2(HttpServletRequest request, HttpSession session) {
		ArrayList<Libro> resultado = Conexion.getAllLibros();
		session.setAttribute("listaLibros", resultado);	
	}
	
	public void option3(HttpServletRequest request, HttpSession session, int id) {
		ArrayList<Libro> listaLibros = (ArrayList<Libro>)session.getAttribute("listaLibros");
		for (Libro unLibro : listaLibros) {
			if (unLibro.getId() == id) {
				session.setAttribute("libro", unLibro);
				request.setAttribute("libro", unLibro);
				break;
			}
		}		
		mensaje = "Libro no encontrado";
	}
	
	public void option4(HttpServletRequest request, HttpSession session) {
		/*Libro unLibro = new Libro();
		unLibro.setId(Integer.parseInt(request.getParameter("id")));
		unLibro.setTitulo(request.getParameter("titulo"));
		unLibro.setAutor(request.getParameter("autor"));
		unLibro.setPrecio(Double.parseDouble(request.getParameter("precio")));
		unLibro.setCatId(Integer.parseInt(request.getParameter("catId")));*/
		Libro libro1 = (Libro)session.getAttribute("libro");
		libro1.setId(Integer.parseInt(request.getParameter("id")));
		libro1.setTitulo(request.getParameter("titulo"));
		libro1.setAutor(request.getParameter("autor"));
		libro1.setPrecio(Double.parseDouble(request.getParameter("precio")));
		libro1.setCatId(Integer.parseInt(request.getParameter("catId")));
		System.out.println("LIBRO1:" + libro1.toString());
		/*System.out.println("unLibro:" + unLibro.toString());*/
		mensaje = "Libro actualizado";
	}
}
